import { Jar } from "./Jar.tsx";
import Statist from "./Statist.tsx";

export function LeftSide() {
    return (
        <div className="w-1/2 bg-[#f3f4f6] rounded-l-3xl flex flex-col items-center justify-evenly">
            <img
                src="https://send.monobank.ua/img/logo_short.svg"
                alt="logo"
                className="mx-auto mt-[42px] mb-6"
            />
            <Jar />
            <div className="font-normal text-md text-center text-black leading-4 mt-1">Покутнєв О. збирає
            </div>
            <div className="font-bold text-md text-center text-black leading-4 mt-1">На ремонт медеваку
            </div>
            <div className="mt-1 font-extrabold text-[22px] text-center">Збираємо на ремонт медеваку для<br />4ОТБР танкова бригада</div>
            <div className="mt-1 min-w-[340px] flex flex-col items-center justify-center mb-auto">
                <div className="text-md font-normal mt-2 text-center mx-auto mb-0 text-black">
                    Ремонтуємо 2 автівки - Тойоту та Нісан.
                    <br />У бригаді є наші земляки з Черкащини!
                    <br />Ремонт авто треба на вчора! Прохання підтримати!
                </div>
                <div className="flex rounded-2xl mx-auto my-0 text-left justify-center mt-4 bg-white">
                    <Statist isRightSide={false} />

                    <Statist isRightSide={true} />
                </div>
            </div>
        </div>
    );
}