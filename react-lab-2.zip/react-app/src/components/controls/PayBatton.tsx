import React from "react";

interface PayBattonProps {
    payType: string,
    pay: () => void,
}

const PayBatton: React.FC<PayBattonProps> = ({ payType, ...props }) => {
    const btnImgSrc: string = payType === 'mono'
        ? 'https://send.monobank.ua/img/mono_pay.svg'
        : 'https://www.gstatic.com/instantbuy/svg/dark_gpay.svg';
    const imgClasses: string = payType !== 'mono'
        ? 'w-[70px] h-[26px]' : '';
    return (
        <div
            className="h-12 my-0 mx-auto min-w-[340px] rounded-xl bg-black overflow-hidden cursor-pointer mb-2 grid place-items-center"
            onClick={props.pay}
        >
            <img src={btnImgSrc} alt="payment-logo" className={imgClasses} />
        </div>
    )
}

export default PayBatton;