import { LeftSide } from "./LeftSide";
import { RightSide } from "./RightSide";

export function Card() {
    return (
        <div className="min-w-[990px] min-h-[680px] rounded-3xl bg-white flex my-4">
            <LeftSide />
            <RightSide />
        </div>
    );
}