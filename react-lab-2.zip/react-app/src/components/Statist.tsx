import React, { useEffect, useState } from "react";
import { balanceProps } from "../models/models.ts";

interface StatistProps {
    isRightSide: boolean;
}


const Statist: React.FC<StatistProps> = (props) => {
    const logoUrl: string = props.isRightSide ? "https://send.monobank.ua/img/target.svg" : "https://send.monobank.ua/img/collected.svg";
    const rightBorder: string = !props.isRightSide ? "  pr-5 border-r border-dividingColor border-opacity-70" : "";
    const label: string = props.isRightSide ? "Ціль" : "Накопичено";
    const [balance, setBalance] = useState<balanceProps>(JSON.parse(localStorage.getItem('balance')!));
    const [sum, setSum] = useState<number>(props.isRightSide ? balance.goal : balance.collected);

    const handleBalanceUpdate = () => {
        const updatedBalance = JSON.parse(localStorage.getItem('balance')!);
        setBalance(updatedBalance);
    };

    useEffect(() => {
        handleBalanceUpdate();
        window.addEventListener('balanceUpdated', handleBalanceUpdate);

        return () => {
            window.removeEventListener('balanceUpdated', handleBalanceUpdate);
        };
    }, []);

    useEffect(() => {
        setSum(props.isRightSide ? balance.goal : balance.collected);
    }, [balance, props.isRightSide]);

    return (
        <div className={"flex relative py-0 px-5 my-3 mx-0 items-center w-1/2"}>
            <img
                src={logoUrl}
                alt="svg-logo"
                className="w-6 h-6 mr-4 min-w-6"
            />
            <div className={"flex flex-col" + rightBorder}>
                <div className="font-semibold text-md text-statsTextColor">{label}</div>
                <div className="font-semibold text-lg text-black">{sum + " ₴"}</div>
            </div>
        </div>
    );
}

export default Statist;