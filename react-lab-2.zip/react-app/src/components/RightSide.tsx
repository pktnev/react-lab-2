import { useEffect, useState } from "react";
import SumBatton from "./controls/SumBatton";
import MyInput from "./controls/MyInput";
import PayBatton from "./controls/PayBatton";
import { useDebounce } from "../hooks/debounce";
import { balanceProps } from "../models/models";
import ManualPayment from "./ManualPayment";

export function RightSide() {

    const [inputValue, setInputValue] = useState<string>('');
    const [isInputValid, setIsInputValid] = useState<boolean>(true);
    const debounced: string = useDebounce(inputValue, 300);
    const [needClearing, setNeedClearing] = useState<boolean>(false);
    const [needClearingManual, setNeedClearingManual] = useState<boolean>(false)
    const [balance, setBalance] = useState<balanceProps>(JSON.parse(localStorage.getItem('balance') || '{}') || {
        collected: 0,
        goal: 0
    });

    const error: string = !isInputValid ? " text-pink-700" : "";
    const placeholderError: string = !isInputValid ? " placeholder-pink-700" : "";
    const inputClasses: string = "opacity-[0.4] flex justify-center items-center font-extrabold text-5xl text-center py-5 px-0 transition-opacity" + error;

    const handleChange = () => {
        if (inputValue === '')
            return;

        const currInputValue: number = parseInt(inputValue);

        if (currInputValue < 10) {
            setIsInputValid(false);
            setInputValue("");
            return;
        } else if (currInputValue > 29999) {
            setInputValue("29999");
            return;
        }

        setIsInputValid(true);
        setInputValue(inputValue);
    };

    const updateInputValue = (value: number) => {
        if (inputValue === '')
            setInputValue(inputValue + value.toString());
        else
            setInputValue(String(parseInt(inputValue) + value))
    };

    const handlePayBattonClick = () => {
        if (isInputValid && inputValue !== '') {
            const updatedBalance: balanceProps = {
                collected: balance.collected + parseInt(inputValue),
                goal: balance.goal
            };
            setBalance(updatedBalance);
            setInputValue('');
            toggleNeedClearing();
            toggleNeedClearingManual();
        }
    };

    const toggleNeedClearing = () => {
        setNeedClearing(!needClearing);
    }

    const toggleNeedClearingManual = () => {
        setNeedClearingManual(!needClearingManual)
    }

    useEffect(() => {
        handleChange()
    }, [debounced]);

    useEffect(() => {
        localStorage.setItem('balance', JSON.stringify(balance));
        window.dispatchEvent(new Event('balanceUpdated'));
    }, [balance]);

    return (
        <div className="w-1/2 bg-white rounded-r-3xl relative min-h-[620px] flex flex-col items-center justify-center">
            <div
                className="w-fit rounded-3xl mt-[42px] mb-8 h-max bg-gradient-to-r from-firstCardGradientCol to-secondCardGradientCol p-[3px]">
                <div className="min-w-[394px] min-h-[163px] p-6 bg-white rounded-3xl flex flex-col justify-center">
                    <div className="text-center font-semibold text-md leading-4 mt-0 flex justify-center items-center">
                        <span>Сума поповнення</span>
                        <img src="https://send.monobank.ua/img/money.png" alt="money"
                            className="w-4 ml-[0.5em] mb-[-3px]" />
                    </div>
                    <div className={inputClasses}>
                        <input
                            type="text"
                            inputMode="numeric"
                            pattern="\d*"
                            value={inputValue}
                            className={"outline-none p-0 w-36 text-right placeholder-gray-950 appearance-none" + placeholderError}
                            placeholder={"0"}
                            style={{ width: inputValue.length > 0 && inputValue.length < 2 ? `${inputValue.length * 0.75 + 2}rem` : inputValue.length >= 2 ? `${inputValue.length * 1.5 + 2}rem` : '2rem' }}
                            onChange={(e) => {
                                const newValue = e.target.value;
                                const regex: RegExp = /^[0-9]*$/;

                                if (regex.test(newValue)) {
                                    setInputValue(newValue);
                                } else {
                                    setInputValue('');
                                }
                            }}
                        />
                        <div className="text-center">
                            &nbsp;₴
                        </div>
                    </div>
                    {!isInputValid &&
                        <span className="text-center text-sm -mt-4 mb-2 ">
                            Сума повинна бути від 10 до 29999
                        </span>
                    }
                    <div className="flex items-center justify-evenly">
                        <SumBatton value={100} updateInputValue={updateInputValue} />
                        <SumBatton value={500} updateInputValue={updateInputValue} />
                        <SumBatton value={1_000} updateInputValue={updateInputValue} />
                    </div>
                </div>
            </div>
            <MyInput
                type={"text"}
                placeholder={"Ваше ім'я (необов'язково)"}
                maxLength={20}
                isNeedClearing={needClearing}
                toggleNeedClearing={toggleNeedClearing}
            />
            <MyInput
                type={"text"}
                placeholder={"Коментар (необов'язково)"}
                maxLength={35}
                isNeedClearing={needClearing}
                toggleNeedClearing={toggleNeedClearing}
            />
            <PayBatton payType={"mono"} pay={handlePayBattonClick} />
            <PayBatton payType={"gPay"} pay={handlePayBattonClick} />
            <ManualPayment needClearing={needClearingManual} toggleClearing={toggleNeedClearingManual}
                pay={handlePayBattonClick} />
        </div>
    );
}