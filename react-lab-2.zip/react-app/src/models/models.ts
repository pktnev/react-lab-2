export interface balanceProps {
    collected: number,
    goal: number,
}