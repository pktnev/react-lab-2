import { Card } from "./components/Card";
import { Footer } from "./components/Footer";
import { balanceProps } from "./models/models";


function App() {
  const initBalanceProps: balanceProps = {
    collected: 0,
    goal: 25000
  }

  localStorage.setItem('balance', JSON.stringify(initBalanceProps));
  return (
    <div
      className="bg-gradient-to-br from-firstBodyGradientCol to-secondBodyGradientCol h-screen w-screen flex flex-col justify-center items-center">
      <Card />
      <Footer />
    </div>
  )
}

export default App